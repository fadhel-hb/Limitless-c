#include <gtk/gtk.h>

typedef struct
{
char nom[100];
char id[100];
char type[100];
char mark[100];
char date[100];
char prix[100];

}capteur;
int ajouter_capteur (capteur c);
void afficher_capteur (GtkWidget *liste);
int modifier_capteur (capteur c);
int supprimer_capteur(char refer[]);
int recherche_capteur (char id[]);
